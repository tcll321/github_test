// MemoryTest.cpp : �������̨Ӧ�ó������ڵ㡣
//
#include "stdafx.h"
// #define _CRTDBG_MAP_ALLOC
// #include <crtdbg.h>
#include <Windows.h>
#include "copy.h"
#include <emmintrin.h>
#include <mmintrin.h>
#include <iostream>
#include "vld.h"
using namespace std;

int MemCopyMMX_PreFetch(unsigned char* Dest,unsigned char* Source,long In)
{
	__asm
	{
		;MMX
		;XMM
			;push ebp ;save registers
			;mov ebp, esp
			;push ebx
			;push esi
			;push edi
			
			mov   eax,In
			mov	  esi,Source
			mov   edi,Dest
			//mov eax, [ebp+16] ; put byte count in eax
			//mov esi, [ebp+12] ; copy source pointer into source index
			//mov edi, [ebp+8] ; copy dest pointer into destination index
			cld ; copy bytes forward

			cmp eax, 64 ; if under 64 bytes long
			jl Under64PreFetch ; jump

			push eax ; place a copy of eax on the stack
			shr eax, 6 ; integer divide eax by 64
			shl eax, 6 ; multiply eax by 64 to get dividend
			mov ecx, eax ; copy it into variable
			pop eax ; retrieve length in eax off the stack
			sub eax, ecx ; subtract dividend from length to get remainder
			mov ebx, eax ; copy remainder into variable
			shr ecx, 6 ; divide by 64 for DWORD data size
			//shr ecx, 6 ;// 64 bytes per iteration
			
			loop1PreFetch:
			
		
			prefetchnta 64[ESI] ;// Prefetch next loop, non-temporal
			//prefetchnta 96[ESI]
			movq mm1, 0[ESI] ;// Read in source data
			movq mm2, 8[ESI]
			movq mm3, 16[ESI]
			movq mm4, 24[ESI]
			movq mm5, 32[ESI]
			movq mm6, 40[ESI]
			movq mm7, 48[ESI]
			movq mm0, 56[ESI]
		

			movntq 0[EDI], mm1 ;// Non-temporal stores
			movntq 8[EDI], mm2
			movntq 16[EDI], mm3
			movntq 24[EDI], mm4
			movntq 32[EDI], mm5
			movntq 40[EDI], mm6
			movntq 48[EDI], mm7
			movntq 56[EDI], mm0
			
			Add esi, 64
			Add edi, 64
			dec ecx
			jnz loop1PreFetch
			
			

			mov eax, ebx ; put remainder in ecx
			Under64PreFetch:
			push eax ; place a copy of eax on the stack
			shr eax, 2 ; integer divide eax by 4
			shl eax, 2 ; multiply eax by 4 to get dividend
			mov ecx, eax ; copy it into variable
			pop eax ; retrieve length in eax off the stack
			sub eax, ecx ; subtract dividend from length to get remainder
			mov ebx, eax ; copy remainder into variable
			shr ecx, 2 ; divide by 4 for DWORD data size
			rep movsd ; repeat while not zero, move string DWORD
			mov ecx, ebx ; put remainder in ecx
			Under4PreFetch:
			rep movsb ; copy remaining BYTES from source to dest
			
			;pop edi
			;pop esi
			;pop ebx
			;mov esp, ebp
			;pop ebp
		    ; ret 12

			emms
	}
	return 0;
}

long fast_copy(unsigned char *src,unsigned char *dst,int len)
{
#define  CACHEBLOCK 400h
	__asm
	{
	mov esi, [src] ; source array
		mov edi, [dst] ; destination array
		mov ecx, [len] ; number of QWORDS (8 bytes) assumes len / CACHEBLOCK is an integer
		shr ecx, 3

		lea esi, [esi+ecx*8] ; end of source
		lea edi, [edi+ecx*8] ; end of destination
		neg ecx ; use a negative offset as a combo pointer-and-loop-counter

		mainloop:
		mov eax, CACHEBLOCK / 16 ; note: .prefetchloop is unrolled 2X
		add ecx, CACHEBLOCK ; move up to end of block

		prefetchloop:
	mov ebx, [esi+ecx*8-64] ; read one address in this cache line...
		mov ebx, [esi+ecx*8-128] ; ... and one in the previous line
		sub ecx, 16 ; 16 QWORDS = 2 64-byte cache lines
		dec eax
		jnz prefetchloop

		mov eax, CACHEBLOCK / 8

		writeloop:
	prefetchnta [esi+ecx*8 + 512] ; fetch ahead by 512 bytes

	movq mm0, [esi+ecx*8]
	movq mm1, [esi+ecx*8+8]
	movq mm2,  [esi+ecx*8+16]
	movq mm3,  [esi+ecx*8+24]
	movq mm4,  [esi+ecx*8+32]
	movq mm5,  [esi+ecx*8+40]
	movq mm6,  [esi+ecx*8+48]
	movq mm7,  [esi+ecx*8+56]

	movntq  [edi+ecx*8], mm0
		movntq  [edi+ecx*8+8], mm1
		movntq  [edi+ecx*8+16], mm2
		movntq  [edi+ecx*8+24], mm3
		movntq  [edi+ecx*8+32], mm4
		movntq  [edi+ecx*8+40], mm5
		movntq  [edi+ecx*8+48], mm6
		movntq  [edi+ecx*8+56], mm7

		add ecx, 8
		dec eax
		jnz writeloop

		or ecx, ecx ; assumes integer number of cacheblocks
		jnz mainloop

		sfence ; flush write buffer
		emms
	}
	return 0;

}

static void __declspec(naked) MMXcopy(void *dst, void *src, int cnt) {
	__asm {
		mov     ecx,[esp+4]
		mov     edx,[esp+8]
		mov		eax,[esp+12]
		emms
copyloop:
		movq    mm0,[edx]
		movq    [ecx],mm0
		add             edx,8
		add             ecx,8
		dec             eax
		jne             copyloop
		emms
		ret
	};
}

 long __fastcall  MyCopySSE(unsigned char *dst,unsigned char* src,int len)
{
	__asm
	{
		mov esi,dst
		mov edi,src
		mov ecx,len

		shr esi,4
		shl esi,4
		shr edi,4
		shl edi,4

		shr ecx,7
		emms


my_loop_sse:
		prefetchnta 128[edi]
		prefetchnta 192[edi]
		movdqa xmm0,0[edi]
		movdqa xmm1,16[edi]
		movdqa xmm2,32[edi]
		movdqa xmm3,48[edi]
		movdqa xmm4,64[edi]
		movdqa xmm5,80[edi]
		movdqa xmm6,96[edi]
		movdqa xmm7,112[edi]

		 
		movntdq 0[esi],xmm0
		movntdq 16[esi],xmm1
		movntdq 32[esi],xmm2
		movntdq 48[esi],xmm3
		movntdq 64[esi],xmm4
		movntdq 80[esi],xmm5 
		movntdq 96[esi],xmm6
		movntdq 112[esi],xmm7

		add esi,128
		add edi,128
		dec ecx
		jnz my_loop_sse
		emms

	}
	return 0;
}
long MyCopyMMX(unsigned char *dst,unsigned char* src,int len)
{
	__asm
	{
		mov esi,dst
		mov edi,src
		mov ecx,len

		shr esi,4
		shl esi,4
		shr edi,4
		shl edi,4

		shr ecx,6
		emms

		
my_loop:
		prefetchnta 64[edi]
		movq mm0,0[edi]
		movq mm1,8[edi]
		movq mm2,16[edi]
		movq mm3,24[edi]
		movq mm4,32[edi]
		movq mm5,40[edi]
		movq mm6,48[edi]
		movq mm7,56[edi]

		movntq 0[esi],mm0
		movntq 8[esi],mm1
		movntq 16[esi],mm2
		movntq 24[esi],mm3
		movntq 32[esi],mm4
		movntq 40[esi],mm5
		movntq 48[esi],mm6
		movntq 56[esi],mm7

		add esi,64
		add edi,64
		dec ecx
		jnz my_loop
		emms

	}
	return 0;
}

void UYVY2YUY2(unsigned char *pDst,unsigned char *pSrc,int len)
{
	const  __int64   csMMX_0x00FF_w  = 0x00FF00FF00FF00FF; //����

	__asm
	{
		    mov eax,pSrc  ; U  Y V Y U Y V Y
			mov edx,pDst  ; Y  U Y V Y U Y V
			mov ecx,len
			shr ecx,3

UV2:
			movq mm0,[eax]
		    movq mm1,mm0	
			psrlw mm1,8
			PSLLW mm0,8
			por mm0,mm1
			movntq [edx],mm0

			add eax,8
			add edx,8
			dec ecx
			jnz UV2
			emms
	}
}



/*
int _tmain(int argc, _TCHAR* argv[])
{
	const int len=1024*1024*8;
	int len2=len/8;
	unsigned char *s1=new unsigned char[len];
	unsigned char *s2=new unsigned char[len];

	//FillMemory(s2,len,'2');

	for (int i=0;i<len;i++)
	{
		int cc=i%16;
		s2[i]=cc*16+cc;
	}
	
	LARGE_INTEGER li1,li2,f;
	QueryPerformanceCounter(&li1);
	QueryPerformanceFrequency(&f);
	int x=0;
	//MemCopyMMX_PreFetch(s1,s2,len);
	//fast_copy(s1,s2,len);
	MyCopySSE(s1,s2,len);
	//MyCopyMMX(s1,s2,len);
	//CopyMemory(s1,s2,len);
	//MMXcopy(s1,s2,len2);
	QueryPerformanceCounter(&li2);

	
	//int sdf=1;

	//__int64 out;
	//__int64 test64=0xff11ff22ff33ff44;
	//UYVY2YUY2((unsigned char*)&out,(unsigned char*)&test64);

	//__m128i a=_mm_load_si128((__m128i *)s1);
	//_mm_store_si128((__m128i *)s2,a);

	//unsigned char *str=s1+7*1024*1024+1023*1024;
	double fl=(li2.QuadPart-li1.QuadPart)*1000000.0/f.QuadPart;

	printf("ʱ��:%lf\n",fl);
	//delete s1;
	//delete s2;
	return 0;
}

*/
void GetMemory(char **p, int num)
{
	*p = (char*)malloc(sizeof(char) * num);//ʹ��newҲ�ܹ�������
}

int _tmain(int argc, _TCHAR* argv[])
{
// 	VLDEnable();
	char *str = NULL;
	string *pString = new string("Hello word!!");
	GetMemory(&str, 100);
// 	cout<<"Memory leak test!"<<endl;
	printf("Memory leak test!\n");
	printf("%s\n", pString);
	//���main�д���whileѭ������GetMemory
	//��ô���⽫��ú�����
	//while(1){GetMemory(...);}
	return 0;
}