// testSTL.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <memory>
#include <map>

class AMFDataStream;
typedef std::tr1::shared_ptr<AMFDataStream> AMFDataStreamPtr;

std::map<int, char*> m_SpsMap;

int _tmain(int argc, _TCHAR* argv[])
{
	m_SpsMap.begin();
	return 0;
}

